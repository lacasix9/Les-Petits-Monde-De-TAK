package fr.lespetitsmondes.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    private final int INK=Color.rgb(54,45,76), PURPLE=Color.rgb(126,83,190),
        PINK=Color.rgb(239,126,178), BLUE=Color.rgb(76,157,220),
        PALE=Color.rgb(250,247,255), GREEN=Color.rgb(73,166,119), GOLD=Color.rgb(244,177,53);
    private LinearLayout root;
    private SharedPreferences data;
    private TextToSpeech tts;
    private String active="Mon enfant", currentWorld="Maternelle", currentClass="Grande section";
    private int questionIndex=0, correctInRun=0;
    private ArrayList<Question> runQuestions=new ArrayList<>();
    private boolean soundEnabled=true;

    static class Question {
        String prompt, hint, answer;
        String[] choices;
        Question(String p,String h,String a,String... c){prompt=p;hint=h;answer=a;choices=c;}
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        data=getSharedPreferences("little_worlds_v1",MODE_PRIVATE);
        active=data.getString("active","Mon enfant");
        soundEnabled=data.getBoolean("sound",true);
        tts=new TextToSpeech(this,status->{});
        showHome();
    }
    @Override public void onDestroy(){ if(tts!=null) tts.shutdown(); super.onDestroy(); }

    private void speak(String s){
        if(soundEnabled && tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"lesson");
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable bg(int color,int radius){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView label(String s,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(12),dp(10),dp(12),dp(10));
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private void page(String title,String subtitle){
        ScrollView sc=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(16),dp(16),dp(24)); root.setBackgroundColor(PALE);
        sc.addView(root); setContentView(sc);
        root.addView(label("🌈 LES PETITS MONDE DE TAK",22,PURPLE,true));
        root.addView(label(title,25,INK,true));
        if(subtitle!=null&&!subtitle.isEmpty())root.addView(label(subtitle,15,INK,false));
    }
    private void btn(String title,int color,Runnable action){
        Button b=new Button(this); b.setText(title); b.setTextSize(17); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setMinHeight(dp(58)); b.setBackground(bg(color,18));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(dp(3),dp(6),dp(3),dp(6)); root.addView(b,lp);
        b.setOnClickListener(v->action.run());
    }
    private void homeButton(){btn("⌂  Accueil",BLUE,this::showHome);}
    private int stars(){return data.getInt(key("stars"),0);}
    private String key(String suffix){return "profile_"+active+"_"+suffix;}

    private void showHome(){
        page("Apprendre en s'amusant !","Bonjour "+active+" ! Tu es prêt(e) à découvrir ?");
        root.addView(label("⭐ "+stars()+" étoiles gagnées",18,GOLD,true));
        btn("🐶  MON MONDE MATERNELLE",PINK,()->showClasses());
        btn("🦄  MON MONDE CP",PURPLE,()->showCP());
        btn("👧  Profils des enfants",BLUE,()->showProfiles());
        btn("🏆  Mes récompenses",GOLD,()->showRewards());
        btn("📚  Mes histoires",GREEN,()->showStories());
        btn("👨‍👩‍👧  Espace parents",INK,()->showParents());
        root.addView(label("Jeu hors connexion • Sans publicité • Sans achat intégré",12,Color.GRAY,false));
    }

    private void showClasses(){
        page("🐶 Le monde du dalmatien","Choisis ta classe. Chaque niveau propose des activités adaptées.");
        btn("🌱 Petite section (PS)",PINK,()->{currentClass="Petite section";showPreschoolSubjects();});
        btn("🌼 Moyenne section (MS)",PINK,()->{currentClass="Moyenne section";showPreschoolSubjects();});
        btn("🌻 Grande section (GS)",PINK,()->{currentClass="Grande section";showPreschoolSubjects();});
        homeButton();
    }
    private void showPreschoolSubjects(){
        page("🐶 "+currentClass,"Le petit dalmatien t'accompagne. Choisis une activité !");
        String[] subjects;
        if(currentClass.startsWith("Petite")) subjects=new String[]{"Couleurs","Formes","Compter","Animaux","Mémoire"};
        else if(currentClass.startsWith("Moyenne")) subjects=new String[]{"Couleurs","Formes","Alphabet","Compter","Logique","Mémoire"};
        else subjects=new String[]{"Alphabet","Sons des lettres","Compter","Graphisme","Logique","Formes"};
        for(String s:subjects)btn("⭐ "+s,PINK,()->startGame(s,currentClass));
        homeButton();
    }
    private void showCP(){
        page("🦄 Le monde de la licorne","Bienvenue au CP ! Choisis ta matière.");
        String[] subjects={"Lecture","Sons et syllabes","Écriture","Mathématiques","Additions","Soustractions","Nombres","Découverte du monde","Anglais"};
        for(String s:subjects)btn("✨ "+s,PURPLE,()->startGame(s,"CP"));
        homeButton();
    }

    private void startGame(String subject,String level){
        currentWorld=subject; questionIndex=0; correctInRun=0;
        runQuestions=questions(subject,level);
        if(runQuestions.isEmpty())runQuestions.add(new Question("Quel est le bon choix ?","Écoute et observe.","Oui","Oui","Essaie encore","Bravo"));
        showQuestion();
    }

    private ArrayList<Question> questions(String s,String level){
        ArrayList<Question> q=new ArrayList<>();
        switch(s){
            case "Couleurs":
                q.add(new Question("Quelle est la couleur du soleil ?","Regarde le soleil ☀️","Jaune","Bleu","Jaune","Vert"));
                q.add(new Question("Quelle couleur obtient-on avec du bleu et du jaune ?","Mélange les couleurs dans ta tête.","Vert","Vert","Rose","Noir")); break;
            case "Formes":
                q.add(new Question("Quelle forme a 3 côtés ?","Compte les côtés.","Triangle","Carré","Rond","Triangle"));
                q.add(new Question("Quelle forme ressemble à une roue ?","Une roue est toute ronde.","Rond","Carré","Triangle","Rond")); break;
            case "Compter":
            case "Nombres":
                q.add(new Question("Combien font 2 pommes et 1 pomme ?","Compte : 🍎 🍎 🍎","3","2","3","4"));
                q.add(new Question("Quel nombre vient après 4 ?","Compte dans l'ordre.","5","3","5","7")); break;
            case "Alphabet":
            case "Sons des lettres":
            case "Lecture":
            case "Sons et syllabes":
            case "Écriture":
                q.add(new Question("Quelle lettre entend-on au début de MAMAN ?","Écoute le premier son : mmmm.","M","A","M","S"));
                q.add(new Question("Quel mot commence comme le son de B dans BATEAU ?","Écoute le premier son.","BALLE","SOLEIL","LUNE","BALLE")); break;
            case "Additions":
            case "Mathématiques":
                q.add(new Question("Combien font 2 + 3 ?","Tu peux compter sur tes doigts.","5","4","5","6"));
                q.add(new Question("Combien font 4 + 1 ?","Ajoute un à quatre.","5","3","5","7")); break;
            case "Soustractions":
                q.add(new Question("Tu as 5 billes. Tu en donnes 2. Combien en reste-t-il ?","Enlève deux billes.","3","2","3","4"));
                q.add(new Question("Combien font 6 - 1 ?","Enlève un à six.","5","4","5","6")); break;
            case "Animaux":
            case "Découverte du monde":
                q.add(new Question("Quel animal fait miaou ?","Écoute son cri.","Le chat","Le chien","Le chat","La vache"));
                q.add(new Question("De quoi une plante a-t-elle besoin pour grandir ?","Pense au jardin.","D'eau et de lumière","De bonbons","D'un ballon","D'eau et de lumière")); break;
            case "Anglais":
                q.add(new Question("Comment dit-on « chat » en anglais ?","Le mot commence par C.","Cat","Dog","Cat","Sun")); break;
            case "Logique":
                q.add(new Question("Quel élément vient ensuite : rouge, bleu, rouge, bleu… ?","Le motif recommence.","Rouge","Vert","Rouge","Jaune")); break;
            case "Mémoire":
                q.add(new Question("Quel animal aboie ?","Pense au compagnon du dalmatien.","Le chien","Le chat","Le chien","Le poisson")); break;
            case "Graphisme":
                q.add(new Question("Quelle ligne ressemble à une route toute droite ?","Une ligne sans virage.","Ligne droite","Zigzag","Ligne droite","Spirale")); break;
            default:
                q.add(new Question("Quel choix est le bon ?","Prends ton temps.","Bravo","Non","Bravo","Peut-être")); break;
        }
        return q;
    }

    private void showQuestion(){
        if(questionIndex>=runQuestions.size()){finishRun();return;}
        Question q=runQuestions.get(questionIndex);
        page("🎮 "+currentWorld,"Question "+(questionIndex+1)+" sur "+runQuestions.size());
        root.addView(label(q.prompt,23,INK,true));
        root.addView(label(q.hint,17,PURPLE,false));
        speak(q.prompt+". "+q.hint);
        for(String choice:q.choices){
            btn(choice,BLUE,()->answer(choice,q));
        }
        btn("🔊 Répéter la consigne",GREEN,()->speak(q.prompt+". "+q.hint));
        btn("⬅ Quitter l'activité",INK,this::showHome);
    }
    private void answer(String choice,Question q){
        if(choice.equals(q.answer)){
            correctInRun++;
            new AlertDialog.Builder(this).setTitle("Bravo ! ⭐").setMessage("Bonne réponse ! Tu as réussi.").setPositiveButton("Continuer",(d,w)->{questionIndex++;showQuestion();}).show();
            speak("Bravo ! Bonne réponse !");
        } else {
            new AlertDialog.Builder(this).setTitle("On réessaie ?").setMessage("Ce n'est pas grave. Écoute l'indice et essaie encore.").setPositiveButton("Réessayer",(d,w)->{}).show();
            speak("Ce n'est pas grave. Tu peux réessayer.");
        }
    }
    private void finishRun(){
        int gained=correctInRun;
        data.edit().putInt(key("stars"),stars()+gained)
            .putInt(key("done"),data.getInt(key("done"),0)+1)
            .putInt(key("correct"),data.getInt(key("correct"),0)+correctInRun).apply();
        page("🏆 Bravo !","Tu as terminé "+currentWorld+" !");
        root.addView(label("⭐ "+gained+" étoile(s) gagnée(s)",24,GOLD,true));
        root.addView(label("Tu as réussi "+correctInRun+" question(s).",18,INK,false));
        btn("Rejouer",PINK,()->startGame(currentWorld,currentClass));
        btn("Choisir une autre activité",PURPLE,()->{if(currentWorld.equals("Lecture")||currentWorld.equals("Mathématiques"))showCP();else if(currentClass.equals("CP"))showCP();else showPreschoolSubjects();});
        homeButton();
    }

    private void showProfiles(){
        page("👧 Profils des enfants","Chaque enfant garde ses propres étoiles et sa progression.");
        Set<String> names=data.getStringSet("profiles",new HashSet<>(Collections.singletonList("Mon enfant")));
        for(String n:new TreeSet<>(names)){
            btn((n.equals(active)?"✓ ":"")+" "+n+"  •  ⭐ "+data.getInt("profile_"+n+"_stars",0),BLUE,()->{
                active=n;data.edit().putString("active",n).apply();showHome();
            });
        }
        btn("➕ Ajouter un profil",PINK,()->{
            EditText input=new EditText(this);input.setHint("Prénom ou surnom");
            new AlertDialog.Builder(this).setTitle("Nouveau profil").setView(input)
              .setNegativeButton("Annuler",null).setPositiveButton("Créer",(d,w)->{
                String n=input.getText().toString().trim();
                if(!n.isEmpty()){
                    Set<String> updated=new HashSet<>(data.getStringSet("profiles",new HashSet<>()));
                    updated.add(n);data.edit().putStringSet("profiles",updated).putString("active",n).apply();
                    active=n;showHome();
                }
              }).show();
        });
        homeButton();
    }

    private void showRewards(){
        page("🏆 Mes récompenses","Continue à jouer pour collectionner les étoiles !");
        root.addView(label("⭐ "+stars()+" étoiles",30,GOLD,true));
        root.addView(label("Activités terminées : "+data.getInt(key("done"),0),18,INK,true));
        root.addView(label("Bonnes réponses : "+data.getInt(key("correct"),0),18,INK,true));
        homeButton();
    }
    private void showStories(){
        page("📚 Histoires à écouter","Des histoires courtes à lire avec un adulte ou à écouter.");
        String[][] stories={{"Le petit dalmatien au jardin","Aujourd'hui, le petit dalmatien découvre les fleurs, les insectes et les couleurs du jardin."},
            {"La licorne et l'arc-en-ciel","Après la pluie, une petite licorne part à la découverte des sept couleurs de l'arc-en-ciel."},
            {"Le voyage de la graine","Une petite graine découvre l'eau, la terre et la lumière pour devenir une fleur."}};
        for(String[] st:stories)btn("📖 "+st[0],PURPLE,()->{
            page(st[0],"Histoire");
            root.addView(label(st[1],21,INK,false));
            btn("🔊 Écouter",GREEN,()->speak(st[1]));
            btn("⬅ Retour aux histoires",BLUE,this::showStories);
        });
        homeButton();
    }
    private void showParents(){
        page("👨‍👩‍👧 Espace parents","Vue locale de démonstration — à sécuriser avant diffusion publique.");
        root.addView(label("Profil : "+active,18,INK,true));
        root.addView(label("Étoiles : "+stars(),18,GOLD,true));
        root.addView(label("Activités terminées : "+data.getInt(key("done"),0),18,INK,false));
        Switch sound=new Switch(this);sound.setText("Voix et consignes parlées");sound.setTextSize(17);
        sound.setChecked(soundEnabled);root.addView(sound);
        sound.setOnCheckedChangeListener((v,on)->{soundEnabled=on;data.edit().putBoolean("sound",on).apply();});
        btn("Réinitialiser la progression de ce profil",PINK,()->new AlertDialog.Builder(this)
            .setMessage("Effacer les étoiles et la progression de "+active+" ?")
            .setNegativeButton("Annuler",null).setPositiveButton("Effacer",(d,w)->{
                data.edit().putInt(key("stars"),0).putInt(key("done"),0).putInt(key("correct"),0).apply();showParents();
            }).show());
        homeButton();
    }
}
